import java.util.ArrayList;

public interface Ennemi
{
    public void tuer(ArrayList<AnimauxFerme> l);
}