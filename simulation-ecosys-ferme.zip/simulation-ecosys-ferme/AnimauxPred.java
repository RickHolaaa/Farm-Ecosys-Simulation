import java.util.ArrayList;
public class AnimauxPred extends Animaux implements Ennemi{

    public AnimauxPred(int hp,String[] mangeable){
        super(hp,mangeable,"AnimauxPred");
    }
    public AnimauxPred reproduire(){
        AnimauxPred a = new AnimauxPred(hp/2,mangeable);
        hp/=2;
        return a;
    }
     public void manger(Ressource res){
        for(int i=0;i<mangeable.length;i++){
            if(mangeable[i]==res.type){
                int q=res.getQuantite();
                res.setQuantite(0);
                if(hp<100)hp+=q;
                if(hp>100)hp=100;
                System.out.println("L'animal "+this.type+" mange"+mangeable[i]);
            }
            else{
                System.out.println("L'animal "+this.type+" ne peut pas manger "+mangeable[i]);
            }
        }
    }
    public void tuer(ArrayList<AnimauxFerme> l){
        for(int i=0; i<l.size();i++)
        {
            AnimauxFerme tmp=l.get(i);
            if (tmp.x== this.x && tmp.y== this.y){
                this.hp+=tmp.hp;
                if(this.hp>100)this.hp=100;
                tmp.hp=0;
                tmp=null;
            }
        }
    }
    public void tuer(ArrayList<Agent> l, Agent a){
        this.hp+=((AnimauxFerme)a).hp;
        l.remove(a);
    }
    public String toString(){
        return "Animal predateur: "+super.toString();
    }
}