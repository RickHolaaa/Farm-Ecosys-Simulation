public class AnimauxFerme extends Animaux{

    public AnimauxFerme(int hp,String[] mangeable,String type){
        super(hp,mangeable,type);
    }

    public void manger(Ressource res){
        boolean test=false;
        for(int i=0;i<mangeable.length;i++){
            if(mangeable[i].equals(res.type)){
                int q = res.getQuantite();
                res.setQuantite(0);
                if(hp<100){ hp+=q; }
                if(hp>100){ hp=100; }
                System.out.println("L'animal "+this.type+" mange "+res.toString());
                test=true;
            }
        }
        if(!test){
            System.out.println("L'animal "+this.type+" n'a pas trouvé de nourriture...");
        }
    }
    public AnimauxFerme reproduire(){
        AnimauxFerme a = new AnimauxFerme(hp/2,mangeable,this.type);
        hp/=2;
        return a;
    }
    public void reduceHp(int enleve){
        this.hp-=enleve;
    }
    public String toString(){
        return "Animal de la ferme: "+super.toString();
    }
}