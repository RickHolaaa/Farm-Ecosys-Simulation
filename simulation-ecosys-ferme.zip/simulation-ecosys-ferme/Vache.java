public class Vache extends AnimauxFerme{
    private int qlait;
  
    public Vache(int v,String[] r,int q){
        super(v,r,"Vache");
        qlait=q;
    }
    public void setLait(){
        if(hp>50){
            qlait+=24;
            hp-=20;
        }
    }
    public int extraire(){
      int qtt = qlait;
      qlait=0;
      System.out.println("Le fermier trait la vache !");
      return qtt;
    }
    public String toString(){
        return super.toString();
    }
  }