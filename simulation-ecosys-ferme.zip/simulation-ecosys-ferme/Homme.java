public abstract class Homme extends Agent
{
    public Homme(int x, int y,String nom)
    {
        super(x,y,nom);
    }
}