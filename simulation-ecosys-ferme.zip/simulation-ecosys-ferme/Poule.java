public class Poule extends AnimauxFerme{
    private int nboeufs=0;

    public Poule(int v,String[] mangeable){
        super(v,mangeable,"Poule");
    }
    public void setOeufs(){
        if(hp>20){
            nboeufs+=10;
            hp-=5;
        }
    }
     public void extraire(int q){
        nboeufs-=q;
        if(nboeufs<0)nboeufs=0;
    }
    public int recupOeuf(){
        if(nboeufs>0){
            int qtt = (int)(Math.random()*nboeufs);
            this.extraire(qtt);
            return qtt;
        }
        return 0;
    }
    public AnimauxFerme reproduire(){
        AnimauxFerme a = new AnimauxFerme(hp/2,mangeable,this.type);
        hp/=2;
        return a;
    }
    public String toString(){
        return super.toString();
    }
}